import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.ArrayDeque; 
import java.net.*; 
import java.io.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class bookmarks extends PApplet {







String[] FileOutput;
String rowTemp;
String infilepath;
String outfile;
String outfilepath;

PFont f;                           // STEP 1 Declare PFont variable

ArrayDeque<JSONObject> q = new ArrayDeque<JSONObject>();

public void fileSelected(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    println("User selected " + selection.getAbsolutePath());
    infilepath=selection.getAbsolutePath();
  }
}

public void fileSelectedout(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    println("User selected out " + selection.getAbsolutePath());
    outfile=selection.getAbsolutePath();
    outfilepath=selection.getParent();
    println("User selected " + selection.getAbsolutePath());
    println("User selected dir " + outfilepath);
    }
}

public void interrupt(int fl) {
  while(fl==0 && infilepath == null) {
    noLoop();
  }
  while(fl==1 && outfilepath == null) {
    noLoop();
  }  
  loop();
}

  
/*void draw() {
  background(255);
  textFont(f,16);                  // STEP 3 Specify font to be used
  fill(0);                         // STEP 4 Specify font color 
  text("Select your JSON chrome bookmarks file and an html file. \nA janusVR environment will be create in the html dir, where url's are websurfaces and folders are links\n",10,100);   // STEP 5 Display Text
}*/

public void setup() {
  
  // select filenames to input and output to... 

  //size(600,600);
  //f = createFont("Arial",16,true); 

 
  selectInput("Export Chrome Bookmarks JSON file to janusVR:", "fileSelected");
  interrupt(0);
  selectOutput("Select a html file to write to:", "fileSelectedout");
  interrupt(1);


  // load the bookmarks

  JSONObject json;
  json = loadJSONObject(infilepath);
  String filepath=outfilepath+"\\";


  // std. top level str of chrome bookmarks.  
  
  String chk = json.getString("checksum");
  JSONObject bm = json.getJSONObject("roots");
  JSONObject bob = bm.getJSONObject("bookmark_bar");
  JSONObject oth = bm.getJSONObject("other");
  FileOutput = new String[0];
 
  // save header
  rowTemp = "<html>\n<head>\n<title>chrome bookmarks in janusVR</title>";
  FileOutput = append(FileOutput, rowTemp);
  rowTemp="</head>\n<body>\n<FireBoxRoom>\n";
  FileOutput = append(FileOutput, rowTemp);

  //commented out custom sykbox
  /*rowTemp="<Assets>\n<AssetImage id=\"sky\" src=\"sky.png\" />";
  FileOutput = append(FileOutput, rowTemp);
  rowTemp="<AssetImage id=\"sky_left\" src=\"left.png\" />\n<AssetImage id=\"sky_right\" src=\"right.png\" />";
  FileOutput = append(FileOutput, rowTemp);
  rowTemp="<AssetImage id=\"sky_front\" src=\"front.png\" />\n<AssetImage id=\"sky_back\" src=\"back.png\" />";
  FileOutput = append(FileOutput, rowTemp);
  rowTemp="<AssetImage id=\"sky_up\" src=\"up.png\" />\n<AssetImage id=\"sky_down\" src=\"down.png\" />";
  FileOutput = append(FileOutput, rowTemp);
  rowTemp="</Assets>\n";
  FileOutput = append(FileOutput, rowTemp);*/
//  rowTemp="<Room use_local_asset=\"room_plane\" pos=\"0.000 0.000 0.000\" col=\"1.000 1.000 1.000\" skybox_left_id=\"sky_left\" skybox_right_id=\"sky_right\" skybox_front_id=\"sky_front\" skybox_back_id=\"sky_back\" skybox_up_id=\"sky_up\" skybox_down_id=\"sky_down\">\n";

  // make top level room
  
  rowTemp="<Room use_local_asset=\"room_plane\" pos=\"0.000 0.000 0.000\" col=\"1.000 1.000 1.000\" >\n";
  
  FileOutput = append(FileOutput, rowTemp);
  
  String tt=bob.getString("name");
  String tt_id=tt.replaceAll(" ", "_").toLowerCase();
  rowTemp="<Link pos=\"2 0 6\" fwd=\"0 0 -1\" url=\"" +tt_id+ ".html\" col=\"0.0 0.6 0.2\" scale=\"2 3 1\" title=\""+tt+"\" />";
  FileOutput = append(FileOutput, rowTemp);
  tt=oth.getString("name");
  tt_id=tt.replaceAll(" ", "_").toLowerCase();
  rowTemp="<Link pos=\"-2 0 6\" fwd=\"0 0 -1\" url=\"" +tt_id+ ".html\" col=\"0.0 0.2 0.6\" scale=\"2 3 1\" title=\""+tt+"\" />";          
  FileOutput = append(FileOutput, rowTemp);
  
  FileOutput = append(FileOutput, "</Room>\n</FireBoxRoom>\n</body>\n</html>");
  //String outfile=filepath+"janusVR_bookmarks.html";
  saveStrings(outfile, FileOutput);  

  // make a room with any dir. setup as linked portals. put these on the queue

  q.add(bob);
  q.add(oth);
  JSONObject bb,bc; 
  //these are all folders, make a seperate html file for each.
  while (!q.isEmpty () ) { 
    bb  = q.removeFirst();
    String title = bb.getString("name");
    String title_id=title.replaceAll(" ", "_").toLowerCase();
    String type = bb.getString("type");
    if (type.equals("folder")) // should always happen
    {
      FileOutput = new String[0];
      rowTemp = "<html>\n<head>\n<title>chrome bookmarks in janusVR</title>";
      FileOutput = append(FileOutput, rowTemp);
      rowTemp="</head>\n<body>\n<FireBoxRoom>\n<Assets>\n";
      FileOutput = append(FileOutput, rowTemp);
      
      //comment out skypbox
      /*rowTemp="<AssetImage id=\"sky\" src=\"sky.png\" />";
      FileOutput = append(FileOutput, rowTemp);
      rowTemp="<AssetImage id=\"sky_left\" src=\"left.png\" />\n<AssetImage id=\"sky_right\" src=\"right.png\" />";
      FileOutput = append(FileOutput, rowTemp);
      rowTemp="<AssetImage id=\"sky_front\" src=\"front.png\" />\n<AssetImage id=\"sky_back\" src=\"back.png\" />";
      FileOutput = append(FileOutput, rowTemp);
      rowTemp="<AssetImage id=\"sky_up\" src=\"up.png\" />\n<AssetImage id=\"sky_down\" src=\"down.png\" />";
      FileOutput = append(FileOutput, rowTemp);
      */
      
     JSONArray ch = bb.getJSONArray("children");    
      for (int i = 0; i < ch.size(); i++) 
      {
        bc=ch.getJSONObject(i);
        String title2 = bc.getString("name");
        String title2_id=title2.replaceAll(" ", "_").replaceAll("&","%26").toLowerCase();   
        String type2 = bc.getString("type");
        if (type2.equals("url") && !title2_id.equals("bookmarks"))  // make a websurface but skip chrome_bookmarks and other titles you dont want
        {
          String url = bc.getString("url");
          url=url.replaceAll("&","%26");
          rowTemp="<AssetWebSurface id=\""+title2_id+ "\" src=\"" +url+ "\" width=\"1280\" height=\"960\"/>";
          FileOutput = append(FileOutput, rowTemp);
          //println(title2 + " " +url);
        }
      }
      rowTemp="</Assets>\n";
      FileOutput = append(FileOutput, rowTemp);
//      rowTemp="<Room use_local_asset=\"room_plane\" pos=\"0.000 0.000 0.000\" col=\"1.000 1.000 1.000\" skybox_left_id=\"sky_left\" skybox_right_id=\"sky_right\" skybox_front_id=\"sky_front\" skybox_back_id=\"sky_back\" skybox_up_id=\"sky_up\" skybox_down_id=\"sky_down\">\n";
      rowTemp="<Room use_local_asset=\"room_plane\" pos=\"0.000 0.000 0.000\" col=\"1.000 1.000 1.000\" >\n";
      FileOutput = append(FileOutput, rowTemp);
      int i=0;
      for (int j = 0; j < ch.size(); j++) 
      {
        
        bc=ch.getJSONObject(j);
        String title2 = bc.getString("name");
        String title2_id=title2.replaceAll(" ", "_").replaceAll("&","%26").toLowerCase();          
        String type2 = bc.getString("type");
        
        if (title2_id.equals("bookmarks"))  // skip title you dont want
        {
          //println(title2_id + " skipping this");
          continue;  // skip chrome bookmarks url, it does not load in webkit
        }
 
        float rad= 0.73f*(i);//0.7854*(i%8);
        float col=PApplet.parseFloat(i)/PApplet.parseFloat(ch.size());
        float posx = -sin(rad);
        float posz = cos(rad);
        float px=(7.0f+i*0.7f)*posx;
        float pz=(7.0f+i*0.6f)*posz;
        i++;
        
        if (type2.equals("url"))           
        {
          
          rowTemp="<Object id=\"plane\" websurface_id=\""+title2_id+"\" zdir=\""+(-1.0f*posx)+" 0 "+(-1.0f*posz)+"\" xdir=\""+posz+" 0 "+(-1.0f*posx)+"\" ydir=\"0 1 0\" pos=\""+px+" 1.5 "+pz+"\" scale=\"4 3 1\"/>";
          FileOutput = append(FileOutput, rowTemp);
        }
        else if (type2.equals("folder")) // make a link to a room
        {
          rowTemp="<Link pos=\""+px+" 0 "+pz+"\" zdir=\""+(-1.0f*posx)+" 0 "+(-1.0f*posz)+"\" xdir=\""+posz+" 0 "+(-1.0f*posx)+"\" ydir=\"0 1 0\" url=\"" +title2_id+ ".html\" col=\"0.0 "+ col+ " 0.2\" scale=\"4 3 1\" title=\""+title2+"\" />";          
          FileOutput = append(FileOutput, rowTemp);
          q.add(bc);
        }    
        else
        {
          println(title + " unhandled");
        }
      }
      FileOutput = append(FileOutput, "</Room>\n</FireBoxRoom>\n</body>\n</html>");
      String outfile2=filepath+title_id+".html";
      saveStrings(outfile2, FileOutput);  
      //println(title + "]]");
    }
  }  
  println("Bookmarks exported successfully");
  exit();
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "bookmarks" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
