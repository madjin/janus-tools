This program exports a JSON chrom bookmarks file to a janusVR environment.
Select the bookmarks file typically in...
C:\Users\<username>\AppData\Local\Google\Chrome\User Data\Default\Bookmarks

and where you want to built the janusVR env. provided the root level file name for eg.

c:\mybookmarks\bm.html

this will create a hierarchical janusVR environment rooted at bm.html, where urls are websurfaces 
and folders are portal links.


The program is built in processing. Feel free to edit the source code to meet your needs.
 
karan singh
janusVR Inc.
sept. 16, 2016.


