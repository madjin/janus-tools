
Tutorial Slides
===============

[This is an offline 2D version of the slides found here](janus://static.croxford.me/SketchUpTutorial/index.html)


![3](images/Slide03.jpg)

![4](images/Slide04.jpg)

[tut_example1.skp](../tutorial/tut_example1.skp)

![5](images/Slide05.jpg)

![6](images/Slide06.jpg)

![7](images/Slide07.jpg)

[tut_example2.skp](../tutorial/tut_example2.skp)

![8](images/Slide08.jpg)

[tut_example3.skp](../tutorial/tut_example3skp)

![9](images/Slide09.jpg)

![10](images/Slide10.jpg)

[tut_example4.skp](../tutorial/tut_example4.skp)

![11](images/Slide11.jpg)

![12](images/Slide12.jpg)

[tut_spotlight.skp](../tutorial/tut_spotlight.skp)
